using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class UI_manager : MonoBehaviour
{
    [SerializeField] private void_event pause_event;


    private void OnEnable()
    {
        pause_event.RegisterListener(OnPause);
    }
    private void OnDisable()
    {
        pause_event.UnregisterListener(OnPause);
    }
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
    private void OnPause()
    {
        Debug.Log("pausing");
    }
}
