using System.Collections;
using UnityEngine;

public class LandEnemy : MonoBehaviour
{
    [SerializeField] private GameObject[] waypoints;
    [SerializeField] private GameObject player;
    [SerializeField] private float speed;
    [SerializeField] private float pushForce; // Define push force here
    [SerializeField] private Animator animator;
    [SerializeField] private bool isattacking;
    [SerializeField] private bool ischasing;
    [SerializeField] private bool isidle;

    private int chase_bool;
    private int idle_bool;
    private int attack_bool;
    private int dead_tirgger;
    private Rigidbody2D RB2D;
    private int currentindex = 0;
    private bool collidedWithPlayer = false;
    private bool reached_waypoint = false;
    private Vector2 playerCollisionPoint; // Store collision point

    private void Start()
    {
        RB2D = GetComponent<Rigidbody2D>();
        chase_bool = Animator.StringToHash("chasing");
        idle_bool =Animator.StringToHash("idle");
        attack_bool = Animator.StringToHash("attacking");
        dead_tirgger = Animator.StringToHash("dead");
       Patrol();
    }

    private void Update()
    {
        if (Vector2.Distance(transform.position, player.transform.position) <= 4)
        {
            Chase();
        }
        else
        {
            if (Vector2.Distance(transform.position, waypoints[currentindex].transform.position) <= 1)
            {
                
            }
            Patrol();
        }
        animator.SetBool(attack_bool, isattacking);
        animator.SetBool(chase_bool, ischasing);
        animator.SetBool(idle_bool, isidle);
    }

    private void Chase()
    {
         ischasing = true;
        Vector2 direction = (player.transform.position - transform.position).normalized;
        RB2D.velocity = direction * speed;

        if (Vector2.Distance(transform.position, player.transform.position) > 4)
        {
            Patrol();
        }
        else if (Vector2.Distance(transform.position, player.transform.position) <= 2)
        {
            StartCoroutine(DoAttack());
        }
    }

    private IEnumerator DoAttack()
    {
        Vector2 direction = (player.transform.position - transform.position).normalized;
        RB2D.velocity = direction * speed;

        yield return new WaitForSeconds(0.1f);

        if (collidedWithPlayer)
        {
            Debug.Log("Attack");
            isattacking = true;
            // Use playerCollisionPoint here to calculate force direction
            Vector2 forceDirection = (new Vector2(transform.position.x, transform.position.y) - playerCollisionPoint).normalized;

            Rigidbody2D playerRB2D = player.GetComponent<Rigidbody2D>();
            playerRB2D.AddForce(forceDirection * pushForce, ForceMode2D.Impulse);
            
            collidedWithPlayer = false;
        }
        isattacking = false;

        yield return new WaitForSeconds(5);
        StartCoroutine(DoAttack());
    }

    private void Patrol()
    {
        Vector2 direction = (waypoints[currentindex].transform.position - transform.position).normalized;
        
        RB2D.velocity = direction.normalized * speed;
        transform.localScale = new Vector3(direction.normalized.x,1,1);
        if (reached_waypoint)
        {
            
            currentindex = (currentindex + 1) % waypoints.Length;

        }
    }
    //private IEnumerator SwitchToIdle()
    //{
    //    isidle = true;
    //    ischasing = false;

        
    //    yield return new WaitForSeconds(animator.GetCurrentAnimatorStateInfo(0).length);

    //    isidle = false;
    //    ischasing = true;
    //}

    private void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.gameObject == player.gameObject)
        {
            collidedWithPlayer = true;

            // Store collision point for use in DoAttack
            playerCollisionPoint = collision.contacts[0].point;
        }
    }
}
